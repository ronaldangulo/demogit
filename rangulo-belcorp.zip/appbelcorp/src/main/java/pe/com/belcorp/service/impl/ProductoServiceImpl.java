package pe.com.belcorp.service.impl;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.belcorp.bean.ProductoBE;
import pe.com.belcorp.mapper.ProductoMapper;
import pe.com.belcorp.service.ProductoService;

@Service("productoService")
public class ProductoServiceImpl implements ProductoService, Serializable {

	/** The Constant serialVersionUID. */
	private static final long	serialVersionUID	= -5462594071637258964L;

	private static final Logger	LOG					= LoggerFactory.getLogger(ProductoServiceImpl.class);

	@Autowired
	private ProductoMapper		productoMapper;

	@Override
	public List<ProductoBE> listar() {

		LOG.info("listar.");
		return productoMapper.listar();
	}

	@Override
	public boolean guardar(ProductoBE productoBE) {

		boolean respuesta = false;
		productoMapper.guardar(productoBE);
		respuesta = true;
		return respuesta;
	}

	@Override
	public boolean actualizar(ProductoBE productoBE) {

		boolean respuesta = false;
		productoMapper.actualizar(productoBE);
		respuesta = true;
		return respuesta;
	}

	@Override
	public ProductoBE obtenerPorId(int id) {

		return productoMapper.obtenerPorId(id);
	}

	@Override
	public boolean eliminar(int id) {

		productoMapper.eliminar(id);
		return true;

	}

}
