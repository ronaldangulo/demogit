
package pe.com.belcorp.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HttpController {

	private static final Logger LOG = LoggerFactory.getLogger(HttpController.class);

	/**
	 * Handle404.
	 *
	 * @version Nov 27, 2016
	 * @param model
	 *            the model
	 * @param request
	 *            the request
	 * @return the string
	 */
	@RequestMapping(value = "/")
	public String main(ModelMap model, HttpServletRequest request) {

		LOG.info("main");
		return "redirect:/index";

	}

	@RequestMapping(value = "/index")
	public String index(ModelMap model, HttpServletRequest request) {

		LOG.info("index");
		return "index";

	}

	@RequestMapping(value = "/error/error404")
	public String handle404(ModelMap model, HttpServletRequest request) {

		LOG.info("error404");
		// Validation de session
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null && auth.isAuthenticated()) {
			return "error404";
		}
		else {
			return "redirect:/index";
		}

	}

}
