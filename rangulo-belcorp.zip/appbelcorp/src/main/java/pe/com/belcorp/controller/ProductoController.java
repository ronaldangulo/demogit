
package pe.com.belcorp.controller;

import java.io.Serializable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import pe.com.belcorp.bean.ProductoBE;
import pe.com.belcorp.library.Constants;
import pe.com.belcorp.service.ProductoService;

@Controller
@RequestMapping("/producto")
public class ProductoController implements Serializable, Constants {

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1157806456199258179L;

	private static final Logger	LOG					= LoggerFactory.getLogger(ProductoController.class);

	@Autowired
	private ProductoService		productoService;

	/**
	 * 
	 * @param model
	 * @param httpServletRequest
	 * @return
	 */
	@RequestMapping(value = "/inicio", method = RequestMethod.GET)
	public String inicio(ModelMap model, HttpServletRequest httpServletRequest) {

		LOG.info("/producto/inicio");

		List<ProductoBE> lstProducto = this.productoService.listar();
		LOG.info("resultados: " + lstProducto.size());
		model.addAttribute("lstProducto", lstProducto);
		return "producto/listar";

	}

}
