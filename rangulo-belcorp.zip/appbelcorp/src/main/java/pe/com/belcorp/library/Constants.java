
package pe.com.belcorp.library;

public interface Constants {

	public static final String	JBOSS_PATH				= System.getProperty("jboss.server.base.dir");

	public static final String	FS						= System.getProperty("file.separator");

	// Password recovery
	public static final int		MINIMUN_LENGTH_FIELD	= 3;

	public static final String	EMPTY					= "";

	public static final String	SP						= " ";

	public static final String	COMMA					= ",";

}
