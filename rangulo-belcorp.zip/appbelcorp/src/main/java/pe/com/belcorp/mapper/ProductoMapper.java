package pe.com.belcorp.mapper;

import java.util.List;

import pe.com.belcorp.bean.ProductoBE;

public interface ProductoMapper {

	/**
	 * 
	 * @param parametros
	 * @return
	 */
	public List<ProductoBE> listar();

	/**
	 * 
	 * @param productoBE
	 * @return
	 */
	public int guardar(ProductoBE productoBE);

	/**
	 * 
	 * @param productoBE
	 * @return
	 */
	public int actualizar(ProductoBE productoBE);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public int eliminar(int id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ProductoBE obtenerPorId(int id);

	
}
