package pe.com.belcorp.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ProductoBE implements Serializable {

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 253224499974153555L;

	private int					id;

	private String				codigoPais;

	private String				codigo;

	private String				descripcion;

	private String				codigoTipoUnidad;

	private double				capacidad;

	private String				estado;

	private Date				fechaCreacion;

	private String				strFechaCreacion;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodigoPais() {
		return codigoPais;
	}

	public void setCodigoPais(String codigoPais) {
		this.codigoPais = codigoPais;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCodigoTipoUnidad() {
		return codigoTipoUnidad;
	}

	public void setCodigoTipoUnidad(String codigoTipoUnidad) {
		this.codigoTipoUnidad = codigoTipoUnidad;
	}

	public double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
		if (this.fechaCreacion != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
			this.strFechaCreacion = sdf.format(fechaCreacion);
		}
	}

	public String getStrFechaCreacion() {
		return strFechaCreacion;
	}

	public void setStrFechaCreacion(String strFechaCreacion) {
		this.strFechaCreacion = strFechaCreacion;
	}

	@Override
	public String toString() {
		return "ProductoBE [id=" + id + ", codigoPais=" + codigoPais + ", codigo=" + codigo + ", descripcion=" + descripcion + ", codigoTipoUnidad="
				+ codigoTipoUnidad + ", capacidad=" + capacidad + ", estado=" + estado + ", fechaCreacion=" + fechaCreacion + ", strFechaCreacion="
				+ strFechaCreacion + "]";
	}

}
