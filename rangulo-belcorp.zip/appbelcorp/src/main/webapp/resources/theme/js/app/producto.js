/**
 * transfer.js Author: Ing. Ronald Angulo. Compaby: BeneTi Software.
 */

$(document).ready(function() {

	$("#desdeFechaProd").datepicker();
	$("#hastaFechaProd").datepicker();

	$('#btnBuscarProducto').click(function(e) {
		buscarProductos();
	});

});

function verProducto(idProducto) {

	var csrf = $("#_csrf").val();
	$.post($("#urlVerProducto").val().trim(), {
		_csrf : csrf,
		id : idProducto
	}, function(response) {

		$("#txtNombreProd").val(response.informacion.nombre);
		$("#txtStockProd").val(response.informacion.stock);
		$("#txtIdProducto").val(response.informacion.idProducto);
		$("#dialogoInformacionProd").dialog({
			resizable : false,
			height : "auto",
			width : 400,
			modal : true,
			buttons : {
				"Guardar" : function() {
					// Guardar por ajax
					actualizarProducto();
				},
				"Cerrar" : function() {
					$(this).dialog("close");
					$("#txtNombreProd").val("");
					$("#txtStockProd").val("");
					$("#txtIdProducto").val("");
					$("#lblMensajeDialogoProd").text('');
					buscarProductos();
				}
			}
		});

	});

}

function agregarProducto() {

	$("#dialogoInformacionProd").dialog({
		resizable : false,
		height : "auto",
		width : 400,
		modal : true,
		buttons : {
			"Guardar" : function() {
				// Guardar por ajax
				guardarProducto();
			},
			"Cerrar" : function() {
				$(this).dialog("close");
				$("#txtNombreProd").val("");
				$("#txtStockProd").val("");
				$("#lblMensajeDialogoProd").text('');
				buscarProductos();
			}
		}
	});
}

function buscarProductos() {

	if ($("#desdeFechaProd").val() == '' || $("#hastaFechaProd").val() == '') {
		$("#txtMensajeDialogo").text("Seleccionar un rango de fechas correctamente.");
		$("#confirmarDialogo").dialog({
			resizable : false,
			height : "auto",
			width : 400,
			modal : true,
			buttons : {
				"Aceptar" : function() {
					$(this).dialog("close");
				}
			}
		});
		return;
	}

	var csrf = $("#_csrf").val();
	var informacion = {
		valor : $("#valor").val(),
		tipoBusquedaBE : {
			id : $("#tipoBusquedaBE").val()
		},
		desdeFecha : $("#desdeFechaProd").val(),
		hastaFecha : $("#hastaFechaProd").val()
	};

	$.post($("#urlBuscarProducto").val().trim(), {
		_csrf : csrf,
		informacion : JSON.stringify(informacion)
	}, function(response) {

		$("#pResultados").text("Alrededor de  " + response.resultados + " resultados.");
		$("#tblProducto > tbody > tr").remove();
		response.informacion.forEach(function(producto) {

			$("#tblProducto").append(
					"<tr>" + "	<td>" + producto.idProducto + "</td>" + "	<td>" + producto.nombre + "</td>" + "	<td>" + producto.stock + "</td>"
							+ "	<td>" + producto.strFechaCreacion + "</td>" + "	<td>" + producto.strFechaModificacion + "</td>" + "	<td>" + "	<td>"
							+ "<span class='input-group-append'>" + "	<button class='btn btn-primary' type='button' onclick='verProducto("
							+ producto.idProducto + ")'>	" + "		<i class='fa fa-pencil-square-o'></i>" + "	</button>" + "</span>" + "	</td>"
							+ "	<td>" + "<span class='input-group-append'>"
							+ "   <button class='btn btn-danger' type='button' onclick='eliminarProducto(" + producto.idProducto + ")'>"
							+ "		<i class='fa fa-trash-o'></i>" + "	</button>" + "</span>" + "	</td>" + "</tr>");
		});

		$("#paginacion").empty();
		response.paginas.forEach(function(pagina) {
			$("#paginacion").append(
					"<li class='page-item'>" + "	<a class='page-link' href='#' onclick='listarPorPagina(" + pagina + "," + response.resultados
							+ ")'>" + pagina + "</a>" + "</li>");
		});

	});
}

function listarPorPagina(pagina, resultados) {

	if ($("#desdeFechaProd").val() == '' || $("#hastaFechaProd").val() == '') {
		$("#txtMensajeDialogo").text("Seleccionar un rango de fechas correctamente.");
		$("#confirmarDialogo").dialog({
			resizable : false,
			height : "auto",
			width : 400,
			modal : true,
			buttons : {
				"Aceptar" : function() {
					$(this).dialog("close");
				}
			}
		});
		return;
	}

	var csrf = $("#_csrf").val();
	var informacion = {
		valor : $("#valor").val(),
		tipoBusquedaBE : {
			id : $("#tipoBusquedaBE").val()
		},
		desdeFecha : $("#desdeFechaProd").val(),
		hastaFecha : $("#hastaFechaProd").val(),
		pagina : pagina,
		resultados : resultados
	};

	$.post($("#urlListarPorPagina").val().trim(), {
		_csrf : csrf,
		informacion : JSON.stringify(informacion)
	}, function(response) {

		$("#pResultados").text("Alrededor de  " + response.resultados + " resultados.");
		$("#tblProducto > tbody > tr").remove();
		response.informacion.forEach(function(producto) {

			$("#tblProducto").append(
					"<tr>" + "	<td>" + producto.idProducto + "</td>" + "	<td>" + producto.nombre + "</td>" + "	<td>" + producto.stock + "</td>"
							+ "	<td>" + producto.strFechaCreacion + "</td>" + "	<td>" + producto.strFechaModificacion + "</td>" + "	<td>" + "	<td>"
							+ "<span class='input-group-append'>" + "	<button class='btn btn-primary' type='button' onclick='verProducto("
							+ producto.idProducto + ")'>	" + "		<i class='fa fa-pencil-square-o'></i>" + "	</button>" + "</span>" + "	</td>"
							+ "	<td>" + "<span class='input-group-append'>"
							+ "   <button class='btn btn-danger' type='button' onclick='eliminarProducto(" + producto.idProducto + ")'>"
							+ "		<i class='fa fa-trash-o'></i>" + "	</button>" + "</span>" + "	</td>" + "</tr>");
		});

		$("#paginacion").empty();
		response.paginas.forEach(function(pagina) {
			$("#paginacion").append(
					"<li class='page-item'>" + "	<a class='page-link' href='#' onclick='listarPorPagina(" + pagina + "," + response.resultados
							+ ")'>" + pagina + "</a>" + "</li>");
		});

	});
}

function eliminarProducto(idProducto) {

	$("#txtMensajeDialogo").text("Este elemento se eliminará de forma permanente y no podrá recuperarse. ¿Estás seguro de eliminarlo?");
	$("#confirmarDialogo").dialog({
		resizable : false,
		height : "auto",
		width : 400,
		modal : true,
		buttons : {
			"Aceptar" : function() {
				$(this).dialog("close");
				// Eliminacion del Producto por ajax.
				var csrf = $("#_csrf").val();
				$.post($("#urlEliminarProducto").val().trim(), {
					_csrf : csrf,
					id : idProducto
				}, function(data) {

					$("#txtMensajeDialogo").text(data.descripcion);
					$("#confirmarDialogo").dialog({
						resizable : false,
						height : "auto",
						width : 400,
						modal : true,
						buttons : {
							"Aceptar" : function() {
								$(this).dialog("close");
								buscarProductos();
							}
						}
					});
					if (data.estado == 201 || data.estado == 200) {
						// clean the row
						$('#tblProducto #producto' + idProducto).remove();
					}
				});

			},
			"Cerrar" : function() {
				$(this).dialog("close");
			}
		}
	});

}

function guardarProducto() {

	// validaciones de informacion.
	if ($("#txtNombreProd").val().trim() == '') {
		$("#lblMensajeDialogoProd").text("Debes ingresar un nombre.");
		return;
	}
	
	if ($("#txtStockProd").val().trim() == '') {
		$("#lblMensajeDialogoProd").text("El stock debe ser un valor numérico.");
		return;
	}

	var csrf = $("#_csrf").val();
	var producto = {
		nombre : $("#txtNombreProd").val(),
		stock : $("#txtStockProd").val()
	};

	// Save the transfer by ajax.
	$.post($("#urlGuardarProducto").val().trim(), {
		_csrf : csrf,
		informacion : JSON.stringify(producto)
	}, function(data) {

		if (data.estado == 201 || data.estado == 200) {
			// Se limpian los campos
			$("#txtIdProducto").val("");
			$("#dialogoInformacionProd").dialog("option", {
				buttons : {
					"Cerrar" : function() {
						$(this).dialog("close");
						$("#txtNombreProd").val("");
						$("#txtStockProd").val("");
						$("#lblMensajeDialogoProd").text('');
						buscarProductos();
					}
				}
			});
		}
		$("#lblMensajeDialogoProd").text(data.descripcion);
	});

}

function actualizarProducto() {

	// validaciones de informacion.
	if ($("#txtNombreProd").val().trim() == '') {
		$("#lblMensajeDialogoProd").text("Debes ingresar un nombre.");
		return;
	}

	var csrf = $("#_csrf").val();
	var producto = {
		idProducto : $("#txtIdProducto").val(),
		nombre : $("#txtNombreProd").val(),
		stock : $("#txtStockProd").val()
	};

	// Save the transfer by ajax.
	$.post($("#urlActualizarProducto").val().trim(), {
		_csrf : csrf,
		informacion : JSON.stringify(producto)
	}, function(data) {

		if (data.estado == 201 || data.estado == 200) {
			// Se limpian los campos
			$("#txtIdProducto").val("");
			$("#dialogoInformacionProd").dialog("option", {
				buttons : {
					"Cerrar" : function() {
						$(this).dialog("close");
						$("#txtNombreProd").val("");
						$("#txtStockProd").val("");
						$("#lblMensajeDialogoProd").text('');
						buscarProductos();
					}
				}
			});
		}
		$("#lblMensajeDialogoProd").text(data.descripcion);
	});

}
